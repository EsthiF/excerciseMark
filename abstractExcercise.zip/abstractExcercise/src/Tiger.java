public class Tiger extends Animal{
    @Override
    public void makeSound() {
        System.out.println("Oarrr I am a Tiger");
    }

    @Override
    public void eat() {
        System.out.println("I eat vegetables and meat ");
    }

    @Override
    public void sleep() {
        System.out.println("I sleep during the day");

    }
}
