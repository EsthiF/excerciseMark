public abstract class Animal {

    public abstract void makeSound();

    public abstract void eat();

    public abstract void sleep();
    }